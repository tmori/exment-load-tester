-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `dashboard_boxes`
--

LOCK TABLES `dashboard_boxes` WRITE;
/*!40000 ALTER TABLE `dashboard_boxes` DISABLE KEYS */;
INSERT INTO `dashboard_boxes` VALUES (1,'fcb3b2dc027f84864753',1,1,1,'お知らせ一覧','list','{\"target_table_id\":8,\"target_view_id\":6}','2022-10-11 00:01:12','2022-10-11 00:01:12',NULL,NULL),(2,'eac3c568d32599e049c9',1,2,1,'ガイドライン','system','{\"target_system_name\":\"guideline\",\"target_system_id\":1}','2022-10-11 00:01:12','2022-10-11 00:01:12',NULL,NULL),(3,'df9c8c34cd52d7ad66bb',1,2,2,'Exment新着情報一覧','system','{\"target_system_name\":\"news\",\"target_system_id\":2}','2022-10-11 00:01:12','2022-10-11 00:01:12',NULL,NULL);
/*!40000 ALTER TABLE `dashboard_boxes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11  9:42:05
