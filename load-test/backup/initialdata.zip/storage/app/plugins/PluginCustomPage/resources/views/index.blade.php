<form method="get">
  <div class="form-group">
    <label for="search">学籍番号を入力</label>
    <input required type="text" class="form-control" id="student_id" name="student_id_input" aria-describedby="searchHelp" placeholder="学籍番号を入力" value="">
    <small id="searchHelp" class="form-text text-muted">学籍番号を入力してください。</small>
  </div>
</form>
