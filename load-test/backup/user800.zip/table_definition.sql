-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_menu`
--

DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL DEFAULT 0,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `menu_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu_target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_operation_log`
--

DROP TABLE IF EXISTS `admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `conditions`
--

DROP TABLE IF EXISTS `conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conditions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `morph_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `morph_id` int(10) unsigned NOT NULL,
  `condition_type` int(11) NOT NULL,
  `condition_key` int(11) NOT NULL,
  `target_column_id` int(11) DEFAULT NULL,
  `condition_value` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conditions_morph_type_morph_id_index` (`morph_type`,`morph_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_column_multisettings`
--

DROP TABLE IF EXISTS `custom_column_multisettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_column_multisettings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_table_id` int(10) unsigned NOT NULL,
  `multisetting_type` int(11) NOT NULL DEFAULT 1,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `priority` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_column_multisettings_suuid_index` (`suuid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_columns`
--

DROP TABLE IF EXISTS `custom_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_table_id` int(10) unsigned NOT NULL,
  `column_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_view_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_flg` tinyint(1) NOT NULL DEFAULT 0,
  `order` int(11) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_columns_custom_table_id_foreign` (`custom_table_id`),
  KEY `custom_columns_suuid_index` (`suuid`),
  KEY `custom_columns_column_name_index` (`column_name`),
  KEY `custom_columns_column_type_index` (`column_type`),
  CONSTRAINT `custom_columns_custom_table_id_foreign` FOREIGN KEY (`custom_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_copies`
--

DROP TABLE IF EXISTS `custom_copies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_copies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_custom_table_id` int(10) unsigned NOT NULL,
  `to_custom_table_id` int(10) unsigned NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_copies_from_custom_table_id_foreign` (`from_custom_table_id`),
  KEY `custom_copies_to_custom_table_id_foreign` (`to_custom_table_id`),
  KEY `custom_copies_suuid_index` (`suuid`),
  CONSTRAINT `custom_copies_from_custom_table_id_foreign` FOREIGN KEY (`from_custom_table_id`) REFERENCES `custom_tables` (`id`),
  CONSTRAINT `custom_copies_to_custom_table_id_foreign` FOREIGN KEY (`to_custom_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_copy_columns`
--

DROP TABLE IF EXISTS `custom_copy_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_copy_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_copy_id` int(10) unsigned NOT NULL,
  `from_column_type` int(11) DEFAULT NULL,
  `from_column_table_id` int(10) unsigned DEFAULT NULL,
  `from_column_target_id` int(11) DEFAULT NULL,
  `to_column_type` int(11) NOT NULL DEFAULT 0,
  `to_column_table_id` int(10) unsigned NOT NULL,
  `to_column_target_id` int(11) NOT NULL,
  `copy_column_type` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_copy_columns_custom_copy_id_foreign` (`custom_copy_id`),
  CONSTRAINT `custom_copy_columns_custom_copy_id_foreign` FOREIGN KEY (`custom_copy_id`) REFERENCES `custom_copies` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_form_blocks`
--

DROP TABLE IF EXISTS `custom_form_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_form_blocks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_form_id` int(10) unsigned NOT NULL,
  `form_block_view_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_block_type` int(11) NOT NULL,
  `form_block_target_table_id` int(10) unsigned DEFAULT NULL,
  `available` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_form_blocks_custom_form_id_foreign` (`custom_form_id`),
  KEY `custom_form_blocks_form_block_target_table_id_foreign` (`form_block_target_table_id`),
  CONSTRAINT `custom_form_blocks_custom_form_id_foreign` FOREIGN KEY (`custom_form_id`) REFERENCES `custom_forms` (`id`),
  CONSTRAINT `custom_form_blocks_form_block_target_table_id_foreign` FOREIGN KEY (`form_block_target_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_form_columns`
--

DROP TABLE IF EXISTS `custom_form_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_form_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_form_block_id` int(10) unsigned NOT NULL,
  `form_column_type` int(11) NOT NULL,
  `form_column_target_id` int(11) DEFAULT NULL,
  `row_no` int(11) NOT NULL DEFAULT 1,
  `column_no` int(11) NOT NULL DEFAULT 1,
  `width` int(11) DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_form_columns_custom_form_block_id_foreign` (`custom_form_block_id`),
  KEY `custom_form_columns_suuid_index` (`suuid`),
  CONSTRAINT `custom_form_columns_custom_form_block_id_foreign` FOREIGN KEY (`custom_form_block_id`) REFERENCES `custom_form_blocks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_form_priorities`
--

DROP TABLE IF EXISTS `custom_form_priorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_form_priorities` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_form_id` int(10) unsigned NOT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_forms`
--

DROP TABLE IF EXISTS `custom_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_table_id` int(10) unsigned NOT NULL,
  `form_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_forms_custom_table_id_foreign` (`custom_table_id`),
  KEY `custom_forms_suuid_index` (`suuid`),
  CONSTRAINT `custom_forms_custom_table_id_foreign` FOREIGN KEY (`custom_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_operation_columns`
--

DROP TABLE IF EXISTS `custom_operation_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_operation_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `custom_operation_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_target_id` int(11) NOT NULL,
  `update_value_text` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation_column_type` int(11) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_operation_columns_custom_operation_id_foreign` (`custom_operation_id`),
  CONSTRAINT `custom_operation_columns_custom_operation_id_foreign` FOREIGN KEY (`custom_operation_id`) REFERENCES `custom_operations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_operations`
--

DROP TABLE IF EXISTS `custom_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_operations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_table_id` int(10) unsigned NOT NULL,
  `operation_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_operations_suuid_index` (`suuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_relation_values`
--

DROP TABLE IF EXISTS `custom_relation_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_relation_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_relation_values_parent_id_index` (`parent_id`),
  KEY `custom_relation_values_child_id_index` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_relations`
--

DROP TABLE IF EXISTS `custom_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_custom_table_id` int(10) unsigned NOT NULL,
  `child_custom_table_id` int(10) unsigned NOT NULL,
  `relation_type` int(11) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_relations_parent_custom_table_id_foreign` (`parent_custom_table_id`),
  KEY `custom_relations_child_custom_table_id_foreign` (`child_custom_table_id`),
  CONSTRAINT `custom_relations_child_custom_table_id_foreign` FOREIGN KEY (`child_custom_table_id`) REFERENCES `custom_tables` (`id`),
  CONSTRAINT `custom_relations_parent_custom_table_id_foreign` FOREIGN KEY (`parent_custom_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_tables`
--

DROP TABLE IF EXISTS `custom_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_flg` tinyint(1) NOT NULL DEFAULT 0,
  `showlist_flg` tinyint(1) NOT NULL DEFAULT 1,
  `order` int(11) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_tables_suuid_index` (`suuid`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_value_authoritables`
--

DROP TABLE IF EXISTS `custom_value_authoritables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_value_authoritables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `authoritable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authoritable_user_org_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authoritable_target_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_value_authoritables_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_value_authoritables_authoritable_type_index` (`authoritable_type`),
  KEY `custom_value_authoritables_authoritable_user_org_type_index` (`authoritable_user_org_type`),
  KEY `custom_value_authoritables_authoritable_target_id_index` (`authoritable_target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_values`
--

DROP TABLE IF EXISTS `custom_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_view_columns`
--

DROP TABLE IF EXISTS `custom_view_columns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_view_columns` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_view_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_table_id` int(10) unsigned NOT NULL,
  `view_column_target_id` int(11) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `view_column_name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_view_columns_custom_view_id_foreign` (`custom_view_id`),
  KEY `custom_view_columns_suuid_index` (`suuid`),
  CONSTRAINT `custom_view_columns_custom_view_id_foreign` FOREIGN KEY (`custom_view_id`) REFERENCES `custom_views` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_view_filters`
--

DROP TABLE IF EXISTS `custom_view_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_view_filters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_view_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_table_id` int(10) unsigned NOT NULL,
  `view_column_target_id` int(11) DEFAULT NULL,
  `view_filter_condition` int(11) NOT NULL,
  `view_filter_condition_value_text` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `view_filter_condition_value_table_id` int(10) unsigned DEFAULT NULL,
  `view_filter_condition_value_id` int(10) unsigned DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_view_filters_custom_view_id_foreign` (`custom_view_id`),
  KEY `custom_view_filters_suuid_index` (`suuid`),
  CONSTRAINT `custom_view_filters_custom_view_id_foreign` FOREIGN KEY (`custom_view_id`) REFERENCES `custom_views` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_view_grid_filters`
--

DROP TABLE IF EXISTS `custom_view_grid_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_view_grid_filters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_view_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_table_id` int(10) unsigned NOT NULL,
  `view_column_target_id` int(11) DEFAULT NULL,
  `order` int(10) unsigned NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_view_grid_filters_custom_view_id_foreign` (`custom_view_id`),
  KEY `custom_view_grid_filters_suuid_index` (`suuid`),
  CONSTRAINT `custom_view_grid_filters_custom_view_id_foreign` FOREIGN KEY (`custom_view_id`) REFERENCES `custom_views` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_view_sorts`
--

DROP TABLE IF EXISTS `custom_view_sorts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_view_sorts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_view_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_table_id` int(10) unsigned NOT NULL,
  `view_column_target_id` int(11) DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  `priority` int(10) unsigned NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_view_sorts_custom_view_id_foreign` (`custom_view_id`),
  KEY `custom_view_sorts_suuid_index` (`suuid`),
  CONSTRAINT `custom_view_sorts_custom_view_id_foreign` FOREIGN KEY (`custom_view_id`) REFERENCES `custom_views` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_view_summaries`
--

DROP TABLE IF EXISTS `custom_view_summaries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_view_summaries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_view_id` int(10) unsigned NOT NULL,
  `view_column_type` int(11) NOT NULL DEFAULT 0,
  `view_column_table_id` int(10) unsigned NOT NULL,
  `view_column_target_id` int(11) DEFAULT NULL,
  `view_summary_condition` int(10) unsigned NOT NULL DEFAULT 0,
  `view_column_name` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_view_summaries_custom_view_id_foreign` (`custom_view_id`),
  KEY `custom_view_summaries_suuid_index` (`suuid`),
  CONSTRAINT `custom_view_summaries_custom_view_id_foreign` FOREIGN KEY (`custom_view_id`) REFERENCES `custom_views` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_views`
--

DROP TABLE IF EXISTS `custom_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_table_id` int(10) unsigned NOT NULL,
  `view_type` int(11) NOT NULL DEFAULT 0,
  `view_kind_type` int(11) NOT NULL DEFAULT 0,
  `view_view_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `custom_options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`custom_options` is null or json_valid(`custom_options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_views_custom_table_id_foreign` (`custom_table_id`),
  KEY `custom_views_suuid_index` (`suuid`),
  CONSTRAINT `custom_views_custom_table_id_foreign` FOREIGN KEY (`custom_table_id`) REFERENCES `custom_tables` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dashboard_boxes`
--

DROP TABLE IF EXISTS `dashboard_boxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_boxes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dashboard_id` int(10) unsigned NOT NULL,
  `row_no` int(11) NOT NULL,
  `column_no` int(11) NOT NULL,
  `dashboard_box_view_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dashboard_box_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_boxes_dashboard_id_foreign` (`dashboard_id`),
  KEY `dashboard_boxes_suuid_index` (`suuid`),
  KEY `dashboard_boxes_row_no_index` (`row_no`),
  KEY `dashboard_boxes_column_no_index` (`column_no`),
  CONSTRAINT `dashboard_boxes_dashboard_id_foreign` FOREIGN KEY (`dashboard_id`) REFERENCES `dashboards` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dashboards`
--

DROP TABLE IF EXISTS `dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboards` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dashboard_type` int(11) NOT NULL DEFAULT 0,
  `dashboard_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dashboard_view_name` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboards_suuid_index` (`suuid`),
  KEY `dashboards_dashboard_name_index` (`dashboard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `data_share_authoritables`
--

DROP TABLE IF EXISTS `data_share_authoritables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_share_authoritables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `authoritable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authoritable_user_org_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `authoritable_target_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `data_share_authoritables_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `data_share_authoritables_authoritable_type_index` (`authoritable_type`),
  KEY `data_share_authoritables_authoritable_user_org_type_index` (`authoritable_user_org_type`),
  KEY `data_share_authoritables_authoritable_target_id_index` (`authoritable_target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_code_verifies`
--

DROP TABLE IF EXISTS `email_code_verifies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_code_verifies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_user_id` int(10) unsigned DEFAULT NULL,
  `verify_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `verify_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valid_period_datetime` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__0a901bfd5c06a9b40e03`
--

DROP TABLE IF EXISTS `exm__0a901bfd5c06a9b40e03`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__0a901bfd5c06a9b40e03` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_002b72ab23a4d7a98137` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."comment_detail"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_002b72ab23a4d7a98137` (`column_002b72ab23a4d7a98137`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__173a948e06f8b4931143`
--

DROP TABLE IF EXISTS `exm__173a948e06f8b4931143`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__173a948e06f8b4931143` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_a22b34814c2202cacc26` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."title"'))) VIRTUAL,
  `column_4beff45005c8e7208205` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."view_flg"'))) VIRTUAL,
  `column_35ff48b26a6379cf4309` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."order"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_a22b34814c2202cacc26` (`column_a22b34814c2202cacc26`),
  KEY `index_column_4beff45005c8e7208205` (`column_4beff45005c8e7208205`),
  KEY `index_column_35ff48b26a6379cf4309` (`column_35ff48b26a6379cf4309`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__17c3830ff06388546478`
--

DROP TABLE IF EXISTS `exm__17c3830ff06388546478`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__17c3830ff06388546478` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_d0d3142d07ecfeeba861` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."student_id"'))) VIRTUAL,
  `column_8c281b3a40a2a4e2113a` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."family_history"'))) VIRTUAL,
  `column_fe1890c91e394468a5a3` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."upbringing_history"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_d0d3142d07ecfeeba861` (`column_d0d3142d07ecfeeba861`),
  KEY `index_column_8c281b3a40a2a4e2113a` (`column_8c281b3a40a2a4e2113a`),
  KEY `index_column_fe1890c91e394468a5a3` (`column_fe1890c91e394468a5a3`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__1dea33e20c36b95d8332`
--

DROP TABLE IF EXISTS `exm__1dea33e20c36b95d8332`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__1dea33e20c36b95d8332` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_89edfc58ed573ebbc99d` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user"'))) VIRTUAL,
  `column_ab653b736c4a78ee1a0e` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_4557d831f40ad00893c7` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."breakfast_staple"'))) VIRTUAL,
  `column_971ba332873fc695e156` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."lunch_staple"'))) VIRTUAL,
  `column_f8cefc6a1168d42b515d` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."dinner_staple"'))) VIRTUAL,
  `column_64d57df0674dc8e3f2fd` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."comment"'))) VIRTUAL,
  `column_0e05e8b0c1235c929519` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."wakeup_time"'))) VIRTUAL,
  `column_5a89e8bbc11015fbedf0` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."sleep_time"'))) VIRTUAL,
  `column_9f5114848975c2c2cbff` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."breakfast_main_dish"'))) VIRTUAL,
  `column_b429845ab7376b9536c5` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."lunch_main_dish"'))) VIRTUAL,
  `column_d7fd07e9218496528946` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."dinner_main_dish"'))) VIRTUAL,
  `column_b72dda461e2db8bea463` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."breakfast_side_dish1"'))) VIRTUAL,
  `column_1459b4e47f730660ce61` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."lunch_side_dish1"'))) VIRTUAL,
  `column_490873604bc810a89e34` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."dinner_side_dish1"'))) VIRTUAL,
  `column_9fbe033907993da22796` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."breakfast_side_dish2"'))) VIRTUAL,
  `column_0e29dd50399da3f0a0b2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."lunch_side_dish2"'))) VIRTUAL,
  `column_c8ce818d17eb08f21b14` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."dinner_side_dish2"'))) VIRTUAL,
  `column_4fc8fb3f55e04055ea4f` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."breakfast_drink"'))) VIRTUAL,
  `column_d33746a6a50588b54cf2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."lunch_drink"'))) VIRTUAL,
  `column_a0dd65e6dbe2f8f5b301` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."dinner_drink"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_89edfc58ed573ebbc99d` (`column_89edfc58ed573ebbc99d`),
  KEY `index_column_ab653b736c4a78ee1a0e` (`column_ab653b736c4a78ee1a0e`),
  KEY `index_column_4557d831f40ad00893c7` (`column_4557d831f40ad00893c7`),
  KEY `index_column_971ba332873fc695e156` (`column_971ba332873fc695e156`),
  KEY `index_column_f8cefc6a1168d42b515d` (`column_f8cefc6a1168d42b515d`),
  KEY `index_column_64d57df0674dc8e3f2fd` (`column_64d57df0674dc8e3f2fd`),
  KEY `index_column_0e05e8b0c1235c929519` (`column_0e05e8b0c1235c929519`),
  KEY `index_column_5a89e8bbc11015fbedf0` (`column_5a89e8bbc11015fbedf0`),
  KEY `index_column_9f5114848975c2c2cbff` (`column_9f5114848975c2c2cbff`),
  KEY `index_column_b429845ab7376b9536c5` (`column_b429845ab7376b9536c5`),
  KEY `index_column_d7fd07e9218496528946` (`column_d7fd07e9218496528946`),
  KEY `index_column_b72dda461e2db8bea463` (`column_b72dda461e2db8bea463`),
  KEY `index_column_1459b4e47f730660ce61` (`column_1459b4e47f730660ce61`),
  KEY `index_column_490873604bc810a89e34` (`column_490873604bc810a89e34`),
  KEY `index_column_9fbe033907993da22796` (`column_9fbe033907993da22796`),
  KEY `index_column_0e29dd50399da3f0a0b2` (`column_0e29dd50399da3f0a0b2`),
  KEY `index_column_c8ce818d17eb08f21b14` (`column_c8ce818d17eb08f21b14`),
  KEY `index_column_4fc8fb3f55e04055ea4f` (`column_4fc8fb3f55e04055ea4f`),
  KEY `index_column_d33746a6a50588b54cf2` (`column_d33746a6a50588b54cf2`),
  KEY `index_column_a0dd65e6dbe2f8f5b301` (`column_a0dd65e6dbe2f8f5b301`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__205a035b05cfd8ec54bf`
--

DROP TABLE IF EXISTS `exm__205a035b05cfd8ec54bf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__205a035b05cfd8ec54bf` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_87b78802aeef7d5ab6b5` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_key_name"'))) VIRTUAL,
  `column_2d0622a84ee1cdee69cd` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_view_name"'))) VIRTUAL,
  `column_a813c28b8221ae9dadf3` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template_type"'))) VIRTUAL,
  `column_be98ed14ff484ac0fe66` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."attachments"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_87b78802aeef7d5ab6b5` (`column_87b78802aeef7d5ab6b5`),
  KEY `index_column_2d0622a84ee1cdee69cd` (`column_2d0622a84ee1cdee69cd`),
  KEY `index_column_a813c28b8221ae9dadf3` (`column_a813c28b8221ae9dadf3`),
  KEY `index_column_be98ed14ff484ac0fe66` (`column_be98ed14ff484ac0fe66`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__232c52d56870c15a91be`
--

DROP TABLE IF EXISTS `exm__232c52d56870c15a91be`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__232c52d56870c15a91be` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_bb492195bd9f6c26acda` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."title"'))) VIRTUAL,
  `column_c2eaff9809e78a183e05` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."view_flg"'))) VIRTUAL,
  `column_e392bac5de743d4946cc` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."order"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_bb492195bd9f6c26acda` (`column_bb492195bd9f6c26acda`),
  KEY `index_column_c2eaff9809e78a183e05` (`column_c2eaff9809e78a183e05`),
  KEY `index_column_e392bac5de743d4946cc` (`column_e392bac5de743d4946cc`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__2ac31d7a374e5ec4a97f`
--

DROP TABLE IF EXISTS `exm__2ac31d7a374e5ec4a97f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__2ac31d7a374e5ec4a97f` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_ed66c17b0574fe9a1da9` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."comment_detail"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_ed66c17b0574fe9a1da9` (`column_ed66c17b0574fe9a1da9`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__2c6bc33f9d5adcd1a380`
--

DROP TABLE IF EXISTS `exm__2c6bc33f9d5adcd1a380`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__2c6bc33f9d5adcd1a380` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_5d0b2decd31a6de192bb` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  `column_aa02ebcba6314a1a7ea8` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."faculty"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_5d0b2decd31a6de192bb` (`column_5d0b2decd31a6de192bb`),
  KEY `index_column_aa02ebcba6314a1a7ea8` (`column_aa02ebcba6314a1a7ea8`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__31184ff24ce10f4c03b2`
--

DROP TABLE IF EXISTS `exm__31184ff24ce10f4c03b2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__31184ff24ce10f4c03b2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_f03deef21fe8fdfd25f7` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."student_id"'))) VIRTUAL,
  `column_465c9eb80fe4262b47ca` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."disability_type"'))) VIRTUAL,
  `column_73b81b464ffeb9cdd2f6` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."diagnostic_name"'))) VIRTUAL,
  `column_2f932d866acee3764ab4` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."support_method"'))) VIRTUAL,
  `column_ce5b4e4a7eed4c694036` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."support_record"'))) VIRTUAL,
  `column_56f0e34070672d6b6c0d` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_965fd2433ea387688906` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."start_time"'))) VIRTUAL,
  `column_fdb00bd8c89ec24963b2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."end_time"'))) VIRTUAL,
  `column_e54c3ebb0250dadc9171` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."staff_id"'))) VIRTUAL,
  `column_137bbf17785b5ff588e3` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."main_complaint"'))) VIRTUAL,
  `column_2ef6f1d59ee2e6e30138` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."consult_id"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_f03deef21fe8fdfd25f7` (`column_f03deef21fe8fdfd25f7`),
  KEY `index_column_465c9eb80fe4262b47ca` (`column_465c9eb80fe4262b47ca`),
  KEY `index_column_73b81b464ffeb9cdd2f6` (`column_73b81b464ffeb9cdd2f6`),
  KEY `index_column_2f932d866acee3764ab4` (`column_2f932d866acee3764ab4`),
  KEY `index_column_ce5b4e4a7eed4c694036` (`column_ce5b4e4a7eed4c694036`),
  KEY `index_column_56f0e34070672d6b6c0d` (`column_56f0e34070672d6b6c0d`),
  KEY `index_column_965fd2433ea387688906` (`column_965fd2433ea387688906`),
  KEY `index_column_fdb00bd8c89ec24963b2` (`column_fdb00bd8c89ec24963b2`),
  KEY `index_column_e54c3ebb0250dadc9171` (`column_e54c3ebb0250dadc9171`),
  KEY `index_column_137bbf17785b5ff588e3` (`column_137bbf17785b5ff588e3`),
  KEY `index_column_2ef6f1d59ee2e6e30138` (`column_2ef6f1d59ee2e6e30138`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__365490ec9b82cde6a80a`
--

DROP TABLE IF EXISTS `exm__365490ec9b82cde6a80a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__365490ec9b82cde6a80a` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_0fdefe57fe2e38b565ef` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_code"'))) VIRTUAL,
  `column_3a99b3786645a446f48e` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_name"'))) VIRTUAL,
  `column_620a76c5549809048735` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."email"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_0fdefe57fe2e38b565ef` (`column_0fdefe57fe2e38b565ef`),
  KEY `index_column_3a99b3786645a446f48e` (`column_3a99b3786645a446f48e`),
  KEY `index_column_620a76c5549809048735` (`column_620a76c5549809048735`)
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__38591674c36abbf51099`
--

DROP TABLE IF EXISTS `exm__38591674c36abbf51099`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__38591674c36abbf51099` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_f57f5805ace2208184bf` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_d2254758157445748e94` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."app_id"'))) VIRTUAL,
  `column_0560aba426dee738c568` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."reason"'))) VIRTUAL,
  `column_74310be118eec979b915` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."contents"'))) VIRTUAL,
  `column_0733428f10cb3970d97c` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."privacy"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_f57f5805ace2208184bf` (`column_f57f5805ace2208184bf`),
  KEY `index_column_d2254758157445748e94` (`column_d2254758157445748e94`),
  KEY `index_column_0560aba426dee738c568` (`column_0560aba426dee738c568`),
  KEY `index_column_74310be118eec979b915` (`column_74310be118eec979b915`),
  KEY `index_column_0733428f10cb3970d97c` (`column_0733428f10cb3970d97c`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__41ad7c9b480822cd3877`
--

DROP TABLE IF EXISTS `exm__41ad7c9b480822cd3877`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__41ad7c9b480822cd3877` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_47dfef241f4026239681` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."document_name"'))) VIRTUAL,
  `column_55406fe67a73e9aeed23` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."file_uuid"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_47dfef241f4026239681` (`column_47dfef241f4026239681`),
  KEY `index_column_55406fe67a73e9aeed23` (`column_55406fe67a73e9aeed23`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__497f8561ee3d72957684`
--

DROP TABLE IF EXISTS `exm__497f8561ee3d72957684`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__497f8561ee3d72957684` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_412a4263f492c667a214` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."company_name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_412a4263f492c667a214` (`column_412a4263f492c667a214`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__4e979f778fe65fc64ac9`
--

DROP TABLE IF EXISTS `exm__4e979f778fe65fc64ac9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__4e979f778fe65fc64ac9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_b4f19aa0d8935af41c69` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_code"'))) VIRTUAL,
  `column_9fbddd885d189235445f` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_name"'))) VIRTUAL,
  `column_1aa6428e6dd69438489e` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."email"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_b4f19aa0d8935af41c69` (`column_b4f19aa0d8935af41c69`),
  KEY `index_column_9fbddd885d189235445f` (`column_9fbddd885d189235445f`),
  KEY `index_column_1aa6428e6dd69438489e` (`column_1aa6428e6dd69438489e`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__59145dd16da6329a3c17`
--

DROP TABLE IF EXISTS `exm__59145dd16da6329a3c17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__59145dd16da6329a3c17` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_13077578939d52001939` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."company_name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_13077578939d52001939` (`column_13077578939d52001939`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__5a944b1abdf044a1bf26`
--

DROP TABLE IF EXISTS `exm__5a944b1abdf044a1bf26`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__5a944b1abdf044a1bf26` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_5b6210bca658053bb5c2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_5b6210bca658053bb5c2` (`column_5b6210bca658053bb5c2`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__5f06343bbe7c446920a9`
--

DROP TABLE IF EXISTS `exm__5f06343bbe7c446920a9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__5f06343bbe7c446920a9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_f1f976d4d5527ac993f5` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."document_name"'))) VIRTUAL,
  `column_6f1c0b6b97c70f8f1333` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."file_uuid"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_f1f976d4d5527ac993f5` (`column_f1f976d4d5527ac993f5`),
  KEY `index_column_6f1c0b6b97c70f8f1333` (`column_6f1c0b6b97c70f8f1333`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__65ac95fd8154eb5492ef`
--

DROP TABLE IF EXISTS `exm__65ac95fd8154eb5492ef`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__65ac95fd8154eb5492ef` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_3c2a2f26ad10208c0380` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_3c2a2f26ad10208c0380` (`column_3c2a2f26ad10208c0380`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__6a7d867515f10d288d5e`
--

DROP TABLE IF EXISTS `exm__6a7d867515f10d288d5e`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__6a7d867515f10d288d5e` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_129cac0f7d2b1df70f97` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user"'))) VIRTUAL,
  `column_6ccf2dc6348cbe1567b6` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template"'))) VIRTUAL,
  `column_a47c051893d8bee32154` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."send_datetime"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_129cac0f7d2b1df70f97` (`column_129cac0f7d2b1df70f97`),
  KEY `index_column_6ccf2dc6348cbe1567b6` (`column_6ccf2dc6348cbe1567b6`),
  KEY `index_column_a47c051893d8bee32154` (`column_a47c051893d8bee32154`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__7331b47ea878a1dc2be2`
--

DROP TABLE IF EXISTS `exm__7331b47ea878a1dc2be2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__7331b47ea878a1dc2be2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_2afd371730c14b96a8a2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user"'))) VIRTUAL,
  `column_fe34359359ec8c731a36` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template"'))) VIRTUAL,
  `column_9b74b64b7839ddf2027b` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."send_datetime"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_2afd371730c14b96a8a2` (`column_2afd371730c14b96a8a2`),
  KEY `index_column_fe34359359ec8c731a36` (`column_fe34359359ec8c731a36`),
  KEY `index_column_9b74b64b7839ddf2027b` (`column_9b74b64b7839ddf2027b`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__7aa8c76a36b3df61aec2`
--

DROP TABLE IF EXISTS `exm__7aa8c76a36b3df61aec2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__7aa8c76a36b3df61aec2` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_710b9876925ed4d1d864` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_code"'))) VIRTUAL,
  `column_bce659ff2999af888b7b` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_name"'))) VIRTUAL,
  `column_db5c6ef37329e28a2661` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."parent_organization"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_710b9876925ed4d1d864` (`column_710b9876925ed4d1d864`),
  KEY `index_column_bce659ff2999af888b7b` (`column_bce659ff2999af888b7b`),
  KEY `index_column_db5c6ef37329e28a2661` (`column_db5c6ef37329e28a2661`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__7c00ae6be404a160ce3d`
--

DROP TABLE IF EXISTS `exm__7c00ae6be404a160ce3d`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__7c00ae6be404a160ce3d` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_2e18b9678a7052a3f0ed` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."document_name"'))) VIRTUAL,
  `column_aec1e1694794650d3da7` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."file_uuid"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_2e18b9678a7052a3f0ed` (`column_2e18b9678a7052a3f0ed`),
  KEY `index_column_aec1e1694794650d3da7` (`column_aec1e1694794650d3da7`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__83b2d1aa4e3a071e55fc`
--

DROP TABLE IF EXISTS `exm__83b2d1aa4e3a071e55fc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__83b2d1aa4e3a071e55fc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_82223d90c256983b3b30` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_code"'))) VIRTUAL,
  `column_e09abcced775443a288a` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_name"'))) VIRTUAL,
  `column_c85692bd282b5929bfdf` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."email"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_82223d90c256983b3b30` (`column_82223d90c256983b3b30`),
  KEY `index_column_e09abcced775443a288a` (`column_e09abcced775443a288a`),
  KEY `index_column_c85692bd282b5929bfdf` (`column_c85692bd282b5929bfdf`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__8585d77ed88cae11e700`
--

DROP TABLE IF EXISTS `exm__8585d77ed88cae11e700`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__8585d77ed88cae11e700` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_7bcef33a181f9b0c3c63` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."target"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_7bcef33a181f9b0c3c63` (`column_7bcef33a181f9b0c3c63`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__8b3f033f29f76fa05334`
--

DROP TABLE IF EXISTS `exm__8b3f033f29f76fa05334`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__8b3f033f29f76fa05334` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_3acad0114637c2bdcb15` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user"'))) VIRTUAL,
  `column_c67aa19435b7ac6718ea` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template"'))) VIRTUAL,
  `column_695f34ddc4b27dc97a21` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."send_datetime"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_3acad0114637c2bdcb15` (`column_3acad0114637c2bdcb15`),
  KEY `index_column_c67aa19435b7ac6718ea` (`column_c67aa19435b7ac6718ea`),
  KEY `index_column_695f34ddc4b27dc97a21` (`column_695f34ddc4b27dc97a21`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__91ec6ff72154c2f1e407`
--

DROP TABLE IF EXISTS `exm__91ec6ff72154c2f1e407`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__91ec6ff72154c2f1e407` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_e475cf06feacf76bedd1` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_e475cf06feacf76bedd1` (`column_e475cf06feacf76bedd1`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__92cfd2451956fb3b81a3`
--

DROP TABLE IF EXISTS `exm__92cfd2451956fb3b81a3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__92cfd2451956fb3b81a3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_6b20c6fcd03bd79efe55` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  `column_8ae82c7cb2dbce43719c` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_id"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_6b20c6fcd03bd79efe55` (`column_6b20c6fcd03bd79efe55`),
  KEY `index_column_8ae82c7cb2dbce43719c` (`column_8ae82c7cb2dbce43719c`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__9588d65988dec2661329`
--

DROP TABLE IF EXISTS `exm__9588d65988dec2661329`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__9588d65988dec2661329` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_ea67a3dd481065527709` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."app_id"'))) VIRTUAL,
  `column_5107cd9380077fb98dfc` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_85bda60ff0519c1e347e` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."deadline"'))) VIRTUAL,
  `column_33de55fbdb7fd3c460c2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."reason"'))) VIRTUAL,
  `column_33254fda93f4f2d9095e` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."special_attention"'))) VIRTUAL,
  `column_aeea2c88fdb944066872` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."privacy"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_ea67a3dd481065527709` (`column_ea67a3dd481065527709`),
  KEY `index_column_5107cd9380077fb98dfc` (`column_5107cd9380077fb98dfc`),
  KEY `index_column_85bda60ff0519c1e347e` (`column_85bda60ff0519c1e347e`),
  KEY `index_column_33de55fbdb7fd3c460c2` (`column_33de55fbdb7fd3c460c2`),
  KEY `index_column_33254fda93f4f2d9095e` (`column_33254fda93f4f2d9095e`),
  KEY `index_column_aeea2c88fdb944066872` (`column_aeea2c88fdb944066872`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__97bd760ea9fcaa30d092`
--

DROP TABLE IF EXISTS `exm__97bd760ea9fcaa30d092`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__97bd760ea9fcaa30d092` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_c57d2ed8cb0f5cefe83a` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."col1"'))) VIRTUAL,
  `column_0af9588afb465d3d55cd` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."col2"'))) VIRTUAL,
  `column_7d17b612c000924c562a` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."col3"'))) VIRTUAL,
  `column_94ab1132a8d89022cca6` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."col4"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_c57d2ed8cb0f5cefe83a` (`column_c57d2ed8cb0f5cefe83a`),
  KEY `index_column_0af9588afb465d3d55cd` (`column_0af9588afb465d3d55cd`),
  KEY `index_column_7d17b612c000924c562a` (`column_7d17b612c000924c562a`),
  KEY `index_column_94ab1132a8d89022cca6` (`column_94ab1132a8d89022cca6`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__9a2c5f89ae9be469c88a`
--

DROP TABLE IF EXISTS `exm__9a2c5f89ae9be469c88a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__9a2c5f89ae9be469c88a` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_3060eddff1d8d304b7b1` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."comment_detail"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_3060eddff1d8d304b7b1` (`column_3060eddff1d8d304b7b1`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__9e7456567f421a4bd872`
--

DROP TABLE IF EXISTS `exm__9e7456567f421a4bd872`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__9e7456567f421a4bd872` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_5b2e19fbcb7c7b14919d` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_5b2e19fbcb7c7b14919d` (`column_5b2e19fbcb7c7b14919d`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__a1ca63a56162e8ee3228`
--

DROP TABLE IF EXISTS `exm__a1ca63a56162e8ee3228`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__a1ca63a56162e8ee3228` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_a747e8c02015c5e0b8cc` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_key_name"'))) VIRTUAL,
  `column_c9e1bba7cb8d31a55563` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_view_name"'))) VIRTUAL,
  `column_24ea8ef4d5ed4b214aec` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template_type"'))) VIRTUAL,
  `column_83a6a3040c899e56fffd` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."attachments"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_a747e8c02015c5e0b8cc` (`column_a747e8c02015c5e0b8cc`),
  KEY `index_column_c9e1bba7cb8d31a55563` (`column_c9e1bba7cb8d31a55563`),
  KEY `index_column_24ea8ef4d5ed4b214aec` (`column_24ea8ef4d5ed4b214aec`),
  KEY `index_column_83a6a3040c899e56fffd` (`column_83a6a3040c899e56fffd`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__aaae4b110b58849077d1`
--

DROP TABLE IF EXISTS `exm__aaae4b110b58849077d1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__aaae4b110b58849077d1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_e2b240b0caedd587d324` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_e2b240b0caedd587d324` (`column_e2b240b0caedd587d324`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__b04dbf1aa9e168e1fccd`
--

DROP TABLE IF EXISTS `exm__b04dbf1aa9e168e1fccd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__b04dbf1aa9e168e1fccd` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_0ab9274a73d375304cee` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_code"'))) VIRTUAL,
  `column_9bfb9488f2324197e4aa` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_name"'))) VIRTUAL,
  `column_4df138f64e467942720f` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."parent_organization"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_0ab9274a73d375304cee` (`column_0ab9274a73d375304cee`),
  KEY `index_column_9bfb9488f2324197e4aa` (`column_9bfb9488f2324197e4aa`),
  KEY `index_column_4df138f64e467942720f` (`column_4df138f64e467942720f`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__b8282cbc3840e839c6ba`
--

DROP TABLE IF EXISTS `exm__b8282cbc3840e839c6ba`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__b8282cbc3840e839c6ba` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_2699591fedbea3cdf654` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."title"'))) VIRTUAL,
  `column_01a15244d24e85c2ced1` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."view_flg"'))) VIRTUAL,
  `column_f6f87c7bfd66ea29bed9` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."order"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_2699591fedbea3cdf654` (`column_2699591fedbea3cdf654`),
  KEY `index_column_01a15244d24e85c2ced1` (`column_01a15244d24e85c2ced1`),
  KEY `index_column_f6f87c7bfd66ea29bed9` (`column_f6f87c7bfd66ea29bed9`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__b8a926f48cfd86ae27c7`
--

DROP TABLE IF EXISTS `exm__b8a926f48cfd86ae27c7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__b8a926f48cfd86ae27c7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_3379f9e8b3e55f32f511` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_8e3a88b44fd6e0b300d6` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."app_id"'))) VIRTUAL,
  `column_91d37d26ce2d18fea304` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."staff"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_3379f9e8b3e55f32f511` (`column_3379f9e8b3e55f32f511`),
  KEY `index_column_8e3a88b44fd6e0b300d6` (`column_8e3a88b44fd6e0b300d6`),
  KEY `index_column_91d37d26ce2d18fea304` (`column_91d37d26ce2d18fea304`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__ba52a09570701bfc6120`
--

DROP TABLE IF EXISTS `exm__ba52a09570701bfc6120`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__ba52a09570701bfc6120` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_2469db2787ad1033c3cd` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user"'))) VIRTUAL,
  `column_bb5f6c5c91d4ce064f2c` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."date"'))) VIRTUAL,
  `column_756710e17b56770d9b23` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_1"'))) VIRTUAL,
  `column_94a31a696d673c3a9d03` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_2"'))) VIRTUAL,
  `column_10cf3fb08bbf91dd8a20` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_3"'))) VIRTUAL,
  `column_f6fd02728ae86b137cb7` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_4"'))) VIRTUAL,
  `column_e797510b0ffe3adabf1b` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_5"'))) VIRTUAL,
  `column_6cd7ccfe5f49d4781fc4` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_6"'))) VIRTUAL,
  `column_e8f6969b133a6d694119` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_7"'))) VIRTUAL,
  `column_551a392ee63f7ff6c119` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_8"'))) VIRTUAL,
  `column_3de7d91fb1c67f36a172` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_9"'))) VIRTUAL,
  `column_c80c6d9a28d306e83ab2` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_10"'))) VIRTUAL,
  `column_05b415e40fdc62a337c5` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."q_11"'))) VIRTUAL,
  `column_f37a9a4b9548715f0b99` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."comment"'))) VIRTUAL,
  `column_7b82ce565c74e3d03756` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."score"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_2469db2787ad1033c3cd` (`column_2469db2787ad1033c3cd`),
  KEY `index_column_bb5f6c5c91d4ce064f2c` (`column_bb5f6c5c91d4ce064f2c`),
  KEY `index_column_756710e17b56770d9b23` (`column_756710e17b56770d9b23`),
  KEY `index_column_94a31a696d673c3a9d03` (`column_94a31a696d673c3a9d03`),
  KEY `index_column_10cf3fb08bbf91dd8a20` (`column_10cf3fb08bbf91dd8a20`),
  KEY `index_column_f6fd02728ae86b137cb7` (`column_f6fd02728ae86b137cb7`),
  KEY `index_column_e797510b0ffe3adabf1b` (`column_e797510b0ffe3adabf1b`),
  KEY `index_column_6cd7ccfe5f49d4781fc4` (`column_6cd7ccfe5f49d4781fc4`),
  KEY `index_column_e8f6969b133a6d694119` (`column_e8f6969b133a6d694119`),
  KEY `index_column_551a392ee63f7ff6c119` (`column_551a392ee63f7ff6c119`),
  KEY `index_column_3de7d91fb1c67f36a172` (`column_3de7d91fb1c67f36a172`),
  KEY `index_column_c80c6d9a28d306e83ab2` (`column_c80c6d9a28d306e83ab2`),
  KEY `index_column_05b415e40fdc62a337c5` (`column_05b415e40fdc62a337c5`),
  KEY `index_column_f37a9a4b9548715f0b99` (`column_f37a9a4b9548715f0b99`),
  KEY `index_column_7b82ce565c74e3d03756` (`column_7b82ce565c74e3d03756`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__be3322efea51c4ee5205`
--

DROP TABLE IF EXISTS `exm__be3322efea51c4ee5205`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__be3322efea51c4ee5205` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_c9d7e48583f1ecd54c7d` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."student_id"'))) VIRTUAL,
  `column_3664b47e56f161e1f7d1` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."diagnosis_date"'))) VIRTUAL,
  `column_e7fa6b66cb6bbd3efaca` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."diagnostic_name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_c9d7e48583f1ecd54c7d` (`column_c9d7e48583f1ecd54c7d`),
  KEY `index_column_3664b47e56f161e1f7d1` (`column_3664b47e56f161e1f7d1`),
  KEY `index_column_e7fa6b66cb6bbd3efaca` (`column_e7fa6b66cb6bbd3efaca`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__c0acc2074e05f102bb9f`
--

DROP TABLE IF EXISTS `exm__c0acc2074e05f102bb9f`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__c0acc2074e05f102bb9f` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_242349223707026b8440` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  `column_a62e3c8edda8a9def2e8` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."student_id"'))) VIRTUAL,
  `column_c18e6b44d3c4d660ffef` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."department"'))) VIRTUAL,
  `column_bfa947e5403b2992b962` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."faculty"'))) VIRTUAL,
  `column_7acf0b7a69390cda010a` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."user_id"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_242349223707026b8440` (`column_242349223707026b8440`),
  KEY `index_column_a62e3c8edda8a9def2e8` (`column_a62e3c8edda8a9def2e8`),
  KEY `index_column_c18e6b44d3c4d660ffef` (`column_c18e6b44d3c4d660ffef`),
  KEY `index_column_bfa947e5403b2992b962` (`column_bfa947e5403b2992b962`),
  KEY `index_column_7acf0b7a69390cda010a` (`column_7acf0b7a69390cda010a`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__de1b8a00ad600f943bd7`
--

DROP TABLE IF EXISTS `exm__de1b8a00ad600f943bd7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__de1b8a00ad600f943bd7` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_c30f93bc8791d9fa11f7` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."company_name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_c30f93bc8791d9fa11f7` (`column_c30f93bc8791d9fa11f7`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__e50f9b83b728183b4791`
--

DROP TABLE IF EXISTS `exm__e50f9b83b728183b4791`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__e50f9b83b728183b4791` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_384929397fc11c32ddf8` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."student_usr"'))) VIRTUAL,
  `column_4e2f99e1cc7d40ae0565` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."consult_id"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_384929397fc11c32ddf8` (`column_384929397fc11c32ddf8`),
  KEY `index_column_4e2f99e1cc7d40ae0565` (`column_4e2f99e1cc7d40ae0565`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__ea9cee48ad123db5471b`
--

DROP TABLE IF EXISTS `exm__ea9cee48ad123db5471b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__ea9cee48ad123db5471b` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_3925b2d1b5e9104a08b0` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."name"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_3925b2d1b5e9104a08b0` (`column_3925b2d1b5e9104a08b0`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__efe35999e7a1957c595b`
--

DROP TABLE IF EXISTS `exm__efe35999e7a1957c595b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__efe35999e7a1957c595b` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_72931a8ce65c17638234` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_code"'))) VIRTUAL,
  `column_84a3555ff172661bec4f` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."organization_name"'))) VIRTUAL,
  `column_fecc89044871cc8bba60` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."parent_organization"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_72931a8ce65c17638234` (`column_72931a8ce65c17638234`),
  KEY `index_column_84a3555ff172661bec4f` (`column_84a3555ff172661bec4f`),
  KEY `index_column_fecc89044871cc8bba60` (`column_fecc89044871cc8bba60`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exm__fc11c1a21eeabbc4c556`
--

DROP TABLE IF EXISTS `exm__fc11c1a21eeabbc4c556`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exm__fc11c1a21eeabbc4c556` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`value` is null or json_valid(`value`)),
  `laravel_admin_escape` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  `column_e7a59bb4ca84500ebfa9` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_key_name"'))) VIRTUAL,
  `column_4179ff011ffb505cb343` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_view_name"'))) VIRTUAL,
  `column_33b84d75b6075de710f1` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."mail_template_type"'))) VIRTUAL,
  `column_865ebc6a1400dd7faf85` varchar(768) CHARACTER SET utf8 GENERATED ALWAYS AS (json_unquote(json_extract(`value`,'$."attachments"'))) VIRTUAL,
  PRIMARY KEY (`id`),
  KEY `custom_values_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `custom_values_suuid_index` (`suuid`),
  KEY `custom_values_deleted_at_index` (`deleted_at`),
  KEY `index_column_e7a59bb4ca84500ebfa9` (`column_e7a59bb4ca84500ebfa9`),
  KEY `index_column_4179ff011ffb505cb343` (`column_4179ff011ffb505cb343`),
  KEY `index_column_33b84d75b6075de710f1` (`column_33b84d75b6075de710f1`),
  KEY `index_column_865ebc6a1400dd7faf85` (`column_865ebc6a1400dd7faf85`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_type` int(11) DEFAULT NULL,
  `local_dirname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `local_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `custom_column_id` int(11) DEFAULT NULL,
  `custom_form_column_id` int(11) DEFAULT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  KEY `files_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `files_local_dirname_index` (`local_dirname`),
  KEY `files_local_filename_index` (`local_filename`),
  KEY `files_filename_index` (`filename`),
  KEY `files_file_type_index` (`file_type`),
  KEY `files_custom_form_column_id_index` (`custom_form_column_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_settings`
--

DROP TABLE IF EXISTS `login_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_view_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `login_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_users`
--

DROP TABLE IF EXISTS `login_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `base_user_id` int(10) unsigned NOT NULL,
  `login_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pure',
  `login_provider` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_reset_flg` tinyint(1) NOT NULL DEFAULT 0,
  `password` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2fa_key` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2fa_available` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `login_users_base_user_id_index` (`base_user_id`),
  KEY `login_users_login_type_index` (`login_type`)
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notifies`
--

DROP TABLE IF EXISTS `notifies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` int(10) unsigned DEFAULT NULL,
  `notify_name` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT 1,
  `custom_table_id` int(10) unsigned NOT NULL,
  `workflow_id` int(10) unsigned DEFAULT NULL,
  `custom_view_id` int(10) unsigned DEFAULT NULL,
  `notify_trigger` int(11) NOT NULL,
  `trigger_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`trigger_settings` is null or json_valid(`trigger_settings`)),
  `notify_actions` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`action_settings` is null or json_valid(`action_settings`)),
  `mail_template_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifies_suuid_index` (`suuid`),
  KEY `notifies_target_id_index` (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `notify_navbars`
--

DROP TABLE IF EXISTS `notify_navbars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notify_navbars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `notify_id` int(10) unsigned NOT NULL,
  `parent_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `target_user_id` int(10) unsigned NOT NULL,
  `trigger_user_id` int(10) unsigned DEFAULT NULL,
  `notify_subject` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notify_body` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_flg` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notify_navbars_parent_type_parent_id_index` (`parent_type`,`parent_id`),
  KEY `notify_navbars_notify_id_index` (`notify_id`),
  KEY `notify_navbars_target_user_id_index` (`target_user_id`),
  KEY `notify_navbars_read_flg_index` (`read_flg`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_api_keys`
--

DROP TABLE IF EXISTS `oauth_api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_api_keys` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_api_keys_key_index` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `api_key_client` tinyint(1) NOT NULL DEFAULT 0,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `password_histories`
--

DROP TABLE IF EXISTS `password_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_user_id` int(10) unsigned NOT NULL,
  `password` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_histories_login_user_id_index` (`login_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pivot__7aa8c76a36b3df61aec2_4e979f778fe65fc64ac9`
--

DROP TABLE IF EXISTS `pivot__7aa8c76a36b3df61aec2_4e979f778fe65fc64ac9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pivot__7aa8c76a36b3df61aec2_4e979f778fe65fc64ac9` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_relation_values_parent_id_index` (`parent_id`),
  KEY `custom_relation_values_child_id_index` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pivot__b04dbf1aa9e168e1fccd_83b2d1aa4e3a071e55fc`
--

DROP TABLE IF EXISTS `pivot__b04dbf1aa9e168e1fccd_83b2d1aa4e3a071e55fc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pivot__b04dbf1aa9e168e1fccd_83b2d1aa4e3a071e55fc` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_relation_values_parent_id_index` (`parent_id`),
  KEY `custom_relation_values_child_id_index` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pivot__efe35999e7a1957c595b_365490ec9b82cde6a80a`
--

DROP TABLE IF EXISTS `pivot__efe35999e7a1957c595b_365490ec9b82cde6a80a`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pivot__efe35999e7a1957c595b_365490ec9b82cde6a80a` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL,
  `child_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_relation_values_parent_id_index` (`parent_id`),
  KEY `custom_relation_values_child_id_index` (`child_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` varchar(256) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plugin_types` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT 1,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `custom_options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`custom_options` is null or json_valid(`custom_options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plugins_uuid_unique` (`uuid`),
  KEY `plugins_plugin_name_index` (`plugin_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `public_forms`
--

DROP TABLE IF EXISTS `public_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `public_forms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `custom_form_id` int(10) unsigned NOT NULL,
  `public_form_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT 0,
  `proxy_user_id` int(10) unsigned NOT NULL,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `public_forms_uuid_unique` (`uuid`),
  KEY `public_forms_custom_form_id_foreign` (`custom_form_id`),
  KEY `public_forms_proxy_user_id_index` (`proxy_user_id`),
  CONSTRAINT `public_forms_custom_form_id_foreign` FOREIGN KEY (`custom_form_id`) REFERENCES `custom_forms` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revisionable_id` int(11) NOT NULL,
  `revision_no` int(10) unsigned NOT NULL DEFAULT 0,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `create_user_id` int(11) DEFAULT NULL,
  `delete_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `revisions_revisionable_id_revisionable_type_index` (`revisionable_id`,`revisionable_type`),
  KEY `revisions_suuid_index` (`suuid`),
  KEY `revisions_key_index` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=802 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_group_permissions`
--

DROP TABLE IF EXISTS `role_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_group_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_group_id` int(10) unsigned NOT NULL,
  `role_group_permission_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_group_target_id` int(11) DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`permissions` is null or json_valid(`permissions`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_group_permissions_role_group_id_foreign` (`role_group_id`),
  KEY `role_group_permissions_role_group_permission_type_index` (`role_group_permission_type`),
  KEY `role_group_permissions_role_group_target_id_index` (`role_group_target_id`),
  CONSTRAINT `role_group_permissions_role_group_id_foreign` FOREIGN KEY (`role_group_id`) REFERENCES `role_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_group_user_organizations`
--

DROP TABLE IF EXISTS `role_group_user_organizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_group_user_organizations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_group_id` int(10) unsigned NOT NULL,
  `role_group_user_org_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_group_target_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_group_user_organizations_role_group_id_foreign` (`role_group_id`),
  KEY `role_group_user_organizations_role_group_user_org_type_index` (`role_group_user_org_type`),
  KEY `role_group_user_organizations_role_group_target_id_index` (`role_group_target_id`),
  CONSTRAINT `role_group_user_organizations_role_group_id_foreign` FOREIGN KEY (`role_group_id`) REFERENCES `role_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_groups`
--

DROP TABLE IF EXISTS `role_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_group_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_group_view_name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `role_groups_role_group_name_unique` (`role_group_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systems`
--

DROP TABLE IF EXISTS `systems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systems` (
  `system_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `system_value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`system_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `base_user_id` int(10) unsigned NOT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`settings` is null or json_valid(`settings`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_settings_base_user_id_index` (`base_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Temporary table structure for view `view_workflow_start`
--

DROP TABLE IF EXISTS `view_workflow_start`;
/*!50001 DROP VIEW IF EXISTS `view_workflow_start`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_workflow_start` (
  `workflow_id` tinyint NOT NULL,
  `workflow_table_id` tinyint NOT NULL,
  `workflow_action_id` tinyint NOT NULL,
  `authority_related_id` tinyint NOT NULL,
  `authority_related_type` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_workflow_value_unions`
--

DROP TABLE IF EXISTS `view_workflow_value_unions`;
/*!50001 DROP VIEW IF EXISTS `view_workflow_value_unions`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `view_workflow_value_unions` (
  `workflow_value_id` tinyint NOT NULL,
  `workflow_id` tinyint NOT NULL,
  `workflow_table_id` tinyint NOT NULL,
  `custom_value_id` tinyint NOT NULL,
  `custom_value_type` tinyint NOT NULL,
  `workflow_action_id` tinyint NOT NULL,
  `authority_related_id` tinyint NOT NULL,
  `authority_related_type` tinyint NOT NULL,
  `last_executed_user_id` tinyint NOT NULL,
  `first_executed_user_id` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `workflow_actions`
--

DROP TABLE IF EXISTS `workflow_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_id` int(10) unsigned NOT NULL,
  `status_from` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ignore_work` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_actions_workflow_id_index` (`workflow_id`),
  KEY `workflow_actions_ignore_work_index` (`ignore_work`),
  CONSTRAINT `workflow_actions_workflow_id_foreign` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_authorities`
--

DROP TABLE IF EXISTS `workflow_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_authorities` (
  `related_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_action_id` int(10) unsigned NOT NULL,
  KEY `workflow_authorities_related_id_related_type_index` (`related_id`,`related_type`),
  KEY `workflow_authorities_workflow_action_id_index` (`workflow_action_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_condition_headers`
--

DROP TABLE IF EXISTS `workflow_condition_headers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_condition_headers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_action_id` int(10) unsigned NOT NULL,
  `status_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_condition_headers_workflow_action_id_index` (`workflow_action_id`),
  CONSTRAINT `workflow_condition_headers_workflow_action_id_foreign` FOREIGN KEY (`workflow_action_id`) REFERENCES `workflow_actions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_statuses`
--

DROP TABLE IF EXISTS `workflow_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_statuses` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_id` int(10) unsigned NOT NULL,
  `status_type` int(10) unsigned NOT NULL DEFAULT 0,
  `order` int(10) unsigned NOT NULL,
  `status_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datalock_flg` tinyint(1) NOT NULL DEFAULT 0,
  `completed_flg` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_statuses_workflow_id_index` (`workflow_id`),
  KEY `workflow_statuses_status_type_index` (`status_type`),
  KEY `workflow_statuses_order_index` (`order`),
  CONSTRAINT `workflow_statuses_workflow_id_foreign` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_tables`
--

DROP TABLE IF EXISTS `workflow_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_id` int(10) unsigned NOT NULL,
  `custom_table_id` int(10) unsigned DEFAULT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT 0,
  `active_start_date` date DEFAULT NULL,
  `active_end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_tables_custom_table_id_foreign` (`custom_table_id`),
  KEY `workflow_tables_workflow_id_index` (`workflow_id`),
  CONSTRAINT `workflow_tables_custom_table_id_foreign` FOREIGN KEY (`custom_table_id`) REFERENCES `custom_tables` (`id`),
  CONSTRAINT `workflow_tables_workflow_id_foreign` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_value_authorities`
--

DROP TABLE IF EXISTS `workflow_value_authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_value_authorities` (
  `related_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `related_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_value_id` int(10) unsigned NOT NULL,
  KEY `workflow_value_authorities_related_id_related_type_index` (`related_id`,`related_type`),
  KEY `workflow_value_authorities_workflow_value_id_index` (`workflow_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_values`
--

DROP TABLE IF EXISTS `workflow_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_values` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_id` int(10) unsigned NOT NULL,
  `morph_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `morph_id` bigint(20) unsigned NOT NULL,
  `workflow_action_id` int(10) unsigned DEFAULT NULL,
  `workflow_status_from_id` int(10) unsigned DEFAULT NULL,
  `workflow_status_to_id` int(10) unsigned DEFAULT NULL,
  `comment` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_executed_flg` tinyint(1) NOT NULL DEFAULT 0,
  `latest_flg` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflow_values_morph_type_morph_id_index` (`morph_type`,`morph_id`),
  KEY `workflow_values_suuid_index` (`suuid`),
  KEY `workflow_values_workflow_id_index` (`workflow_id`),
  KEY `workflow_values_workflow_action_id_index` (`workflow_action_id`),
  KEY `workflow_values_workflow_status_from_id_index` (`workflow_status_from_id`),
  KEY `workflow_values_workflow_status_to_id_index` (`workflow_status_to_id`),
  KEY `workflow_values_action_executed_flg_index` (`action_executed_flg`),
  KEY `workflow_values_latest_flg_index` (`latest_flg`),
  KEY `workflow_values_created_user_id_index` (`created_user_id`),
  CONSTRAINT `workflow_values_workflow_id_foreign` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`),
  CONSTRAINT `workflow_values_workflow_status_from_id_foreign` FOREIGN KEY (`workflow_status_from_id`) REFERENCES `workflow_statuses` (`id`),
  CONSTRAINT `workflow_values_workflow_status_to_id_foreign` FOREIGN KEY (`workflow_status_to_id`) REFERENCES `workflow_statuses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflows`
--

DROP TABLE IF EXISTS `workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `suuid` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_type` int(11) NOT NULL DEFAULT 0,
  `workflow_view_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_status_name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `setting_completed_flg` tinyint(1) NOT NULL DEFAULT 0,
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (`options` is null or json_valid(`options`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_user_id` int(10) unsigned DEFAULT NULL,
  `updated_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `workflows_suuid_index` (`suuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Final view structure for view `view_workflow_start`
--

/*!50001 DROP TABLE IF EXISTS `view_workflow_start`*/;
/*!50001 DROP VIEW IF EXISTS `view_workflow_start`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`exment_user`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `view_workflow_start` AS select distinct `workflows`.`id` AS `workflow_id`,`workflow_tables`.`custom_table_id` AS `workflow_table_id`,`workflow_actions`.`id` AS `workflow_action_id`,`workflow_authorities`.`related_id` AS `authority_related_id`,`workflow_authorities`.`related_type` AS `authority_related_type` from (((`workflow_tables` join `workflows` on(`workflow_tables`.`workflow_id` = `workflows`.`id`)) join `workflow_actions` on(`workflow_actions`.`workflow_id` = `workflows`.`id` and `workflow_actions`.`status_from` = 'start')) join `workflow_authorities` on(`workflow_authorities`.`workflow_action_id` = `workflow_actions`.`id`)) where `workflow_tables`.`active_flg` = 1 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_workflow_value_unions`
--

/*!50001 DROP TABLE IF EXISTS `view_workflow_value_unions`*/;
/*!50001 DROP VIEW IF EXISTS `view_workflow_value_unions`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`exment_user`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `view_workflow_value_unions` AS (select distinct `exment_database`.`workflow_values`.`id` AS `workflow_value_id`,`exment_database`.`workflows`.`id` AS `workflow_id`,`exment_database`.`workflow_tables`.`custom_table_id` AS `workflow_table_id`,`exment_database`.`workflow_values`.`morph_id` AS `custom_value_id`,`exment_database`.`workflow_values`.`morph_type` AS `custom_value_type`,`exment_database`.`workflow_actions`.`id` AS `workflow_action_id`,`exment_database`.`workflow_value_authorities`.`related_id` AS `authority_related_id`,`exment_database`.`workflow_value_authorities`.`related_type` AS `authority_related_type`,`workflow_values_last`.`created_user_id` AS `last_executed_user_id`,`workflow_values_first`.`created_user_id` AS `first_executed_user_id` from (((((((((`exment_database`.`workflow_tables` join `exment_database`.`workflows` on(`exment_database`.`workflow_tables`.`workflow_id` = `exment_database`.`workflows`.`id`)) join `exment_database`.`custom_tables` on(`exment_database`.`workflow_tables`.`custom_table_id` = `exment_database`.`custom_tables`.`id`)) join `exment_database`.`workflow_values` on(`exment_database`.`workflow_values`.`morph_type` = `exment_database`.`custom_tables`.`table_name` and `exment_database`.`workflow_values`.`workflow_id` = `exment_database`.`workflows`.`id`)) join `exment_database`.`workflow_actions` on(`exment_database`.`workflow_actions`.`workflow_id` = `exment_database`.`workflows`.`id` and `exment_database`.`workflow_actions`.`ignore_work` = 0 and (`exment_database`.`workflow_actions`.`status_from` = 'start' and `exment_database`.`workflow_values`.`workflow_status_to_id` is null or `exment_database`.`workflow_actions`.`status_from` = `exment_database`.`workflow_values`.`workflow_status_to_id`))) join `exment_database`.`workflow_value_authorities` on(`exment_database`.`workflow_value_authorities`.`workflow_value_id` = `exment_database`.`workflow_values`.`id`)) join (select `exment_database`.`workflow_values`.`morph_id` AS `morph_id`,`exment_database`.`workflow_values`.`morph_type` AS `morph_type`,max(`exment_database`.`workflow_values`.`id`) AS `workflow_value_first_id` from `exment_database`.`workflow_values` where `exment_database`.`workflow_values`.`workflow_status_from_id` is null group by `exment_database`.`workflow_values`.`morph_id`,`exment_database`.`workflow_values`.`morph_type`) `workflow_values_first_group` on(`workflow_values_first_group`.`morph_id` = `exment_database`.`workflow_values`.`morph_id` and `workflow_values_first_group`.`morph_type` = `exment_database`.`workflow_values`.`morph_type`)) join `exment_database`.`workflow_values` `workflow_values_first` on(`workflow_values_first`.`id` = `workflow_values_first_group`.`workflow_value_first_id`)) join (select `exment_database`.`workflow_values`.`morph_id` AS `morph_id`,`exment_database`.`workflow_values`.`morph_type` AS `morph_type`,max(`exment_database`.`workflow_values`.`id`) AS `workflow_value_last_id` from `exment_database`.`workflow_values` where `exment_database`.`workflow_values`.`action_executed_flg` = 0 group by `exment_database`.`workflow_values`.`morph_id`,`exment_database`.`workflow_values`.`morph_type`) `workflow_values_last_group` on(`workflow_values_last_group`.`morph_id` = `exment_database`.`workflow_values`.`morph_id` and `workflow_values_last_group`.`morph_type` = `exment_database`.`workflow_values`.`morph_type`)) join `exment_database`.`workflow_values` `workflow_values_last` on(`workflow_values_last`.`id` = `workflow_values_last_group`.`workflow_value_last_id`)) where `exment_database`.`workflow_values`.`latest_flg` = 1 and `exment_database`.`workflow_tables`.`active_flg` = 1) union (select distinct `exment_database`.`workflow_values`.`id` AS `workflow_value_id`,`exment_database`.`workflows`.`id` AS `workflow_id`,`exment_database`.`workflow_tables`.`custom_table_id` AS `workflow_table_id`,`exment_database`.`workflow_values`.`morph_id` AS `custom_value_id`,`exment_database`.`workflow_values`.`morph_type` AS `custom_value_type`,`exment_database`.`workflow_actions`.`id` AS `workflow_action_id`,`exment_database`.`workflow_authorities`.`related_id` AS `authority_related_id`,`exment_database`.`workflow_authorities`.`related_type` AS `authority_related_type`,`workflow_values_last`.`created_user_id` AS `last_executed_user_id`,`workflow_values_first`.`created_user_id` AS `first_executed_user_id` from (((((((((`exment_database`.`workflow_tables` join `exment_database`.`workflows` on(`exment_database`.`workflow_tables`.`workflow_id` = `exment_database`.`workflows`.`id`)) join `exment_database`.`custom_tables` on(`exment_database`.`workflow_tables`.`custom_table_id` = `exment_database`.`custom_tables`.`id`)) join `exment_database`.`workflow_values` on(`exment_database`.`workflow_values`.`morph_type` = `exment_database`.`custom_tables`.`table_name` and `exment_database`.`workflow_values`.`workflow_id` = `exment_database`.`workflows`.`id`)) join `exment_database`.`workflow_actions` on(`exment_database`.`workflow_actions`.`workflow_id` = `exment_database`.`workflows`.`id` and `exment_database`.`workflow_actions`.`ignore_work` = 0 and (`exment_database`.`workflow_actions`.`status_from` = 'start' and `exment_database`.`workflow_values`.`workflow_status_to_id` is null or `exment_database`.`workflow_actions`.`status_from` = `exment_database`.`workflow_values`.`workflow_status_to_id`))) join `exment_database`.`workflow_authorities` on(`exment_database`.`workflow_authorities`.`workflow_action_id` = `exment_database`.`workflow_actions`.`id`)) join (select `exment_database`.`workflow_values`.`morph_id` AS `morph_id`,`exment_database`.`workflow_values`.`morph_type` AS `morph_type`,max(`exment_database`.`workflow_values`.`id`) AS `workflow_value_first_id` from `exment_database`.`workflow_values` where `exment_database`.`workflow_values`.`workflow_status_from_id` is null group by `exment_database`.`workflow_values`.`morph_id`,`exment_database`.`workflow_values`.`morph_type`) `workflow_values_first_group` on(`workflow_values_first_group`.`morph_id` = `exment_database`.`workflow_values`.`morph_id` and `workflow_values_first_group`.`morph_type` = `exment_database`.`workflow_values`.`morph_type`)) join `exment_database`.`workflow_values` `workflow_values_first` on(`workflow_values_first`.`id` = `workflow_values_first_group`.`workflow_value_first_id`)) join (select `exment_database`.`workflow_values`.`morph_id` AS `morph_id`,`exment_database`.`workflow_values`.`morph_type` AS `morph_type`,max(`exment_database`.`workflow_values`.`id`) AS `workflow_value_last_id` from `exment_database`.`workflow_values` where `exment_database`.`workflow_values`.`action_executed_flg` = 0 group by `exment_database`.`workflow_values`.`morph_id`,`exment_database`.`workflow_values`.`morph_type`) `workflow_values_last_group` on(`workflow_values_last_group`.`morph_id` = `exment_database`.`workflow_values`.`morph_id` and `workflow_values_last_group`.`morph_type` = `exment_database`.`workflow_values`.`morph_type`)) join `exment_database`.`workflow_values` `workflow_values_last` on(`workflow_values_last`.`id` = `workflow_values_last_group`.`workflow_value_last_id`)) where `exment_database`.`workflow_values`.`latest_flg` = 1 and `exment_database`.`workflow_tables`.`active_flg` = 1) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 10:40:40
