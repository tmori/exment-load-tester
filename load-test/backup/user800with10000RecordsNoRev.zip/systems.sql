-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `systems`
--

LOCK TABLES `systems` WRITE;
/*!40000 ALTER TABLE `systems` DISABLE KEYS */;
INSERT INTO `systems` VALUES ('api_available','1','2022-10-11 00:01:06','2022-10-11 00:38:20',NULL,1),('api_ip_filters',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('custom_value_save_autoshare','0','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('data_submit_redirect','4','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('datalist_pager_count','5','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('default_date_format','format_default','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('filter_multi_user','-1','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('filter_search_type','all','2022-10-11 00:01:06','2022-10-11 04:09:22',NULL,1),('grid_filter_disable_flg','','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('grid_pager_count','20','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('header_user_info','created_at','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('initialized','1','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('org_joined_type_custom_value','0','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('org_joined_type_role_group','99','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('organization_available','1','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('outside_api','1','2022-10-11 00:01:05','2022-10-11 00:01:05',NULL,NULL),('permission_available','1','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('publicform_available','0','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('recaptcha_secret_key',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('recaptcha_site_key',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('recaptcha_type',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('show_default_login_provider','1','2022-10-11 00:01:07','2022-10-11 00:01:07',NULL,NULL),('site_favicon',NULL,'2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_layout','layout_default','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_logo',NULL,'2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_logo_mini',NULL,'2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_name','Exment','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_name_short','Exm','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('site_skin','skin-blue-light','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL),('system_admin_users','1','2022-10-11 00:01:05','2022-10-11 00:01:51',NULL,NULL),('system_mail_body_type','html','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_encryption',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_from','no-reply@hogehoge.com','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_from_view_name',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_host',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_password',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_port',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_mail_username',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_slack_user_column',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('system_values_pos','top','2022-10-11 04:09:22','2022-10-11 04:09:22',1,1),('userdashboard_available','0','2022-10-11 00:01:08','2022-10-11 00:01:08',NULL,NULL),('userview_available','0','2022-10-11 00:01:08','2022-10-11 00:01:08',NULL,NULL),('web_ip_filters',NULL,'2022-10-11 04:09:22','2022-10-11 04:09:22',1,1);
/*!40000 ALTER TABLE `systems` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-12 14:16:29
