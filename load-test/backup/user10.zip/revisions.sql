-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,'e980fa835d8760dc57c3','user',1,1,'value',NULL,'{\"user_code\":\"root\",\"user_name\":\"root\",\"email\":\"root@example.com\"}','2022-10-11 00:01:51','2022-10-11 00:01:51',NULL,NULL,NULL),(2,'ba8de548d21da4a0cd16','user',2,1,'value',NULL,'{\"user_code\":\"test-user1\",\"user_name\":\"test-user1\",\"email\":\"test-user1@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(3,'8f0fbedced02a419edc6','user',3,1,'value',NULL,'{\"user_code\":\"test-user2\",\"user_name\":\"test-user2\",\"email\":\"test-user2@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(4,'2cf854107d27f1b54882','user',4,1,'value',NULL,'{\"user_code\":\"test-user3\",\"user_name\":\"test-user3\",\"email\":\"test-user3@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(5,'a4a45c813156fa9a5391','user',5,1,'value',NULL,'{\"user_code\":\"test-user4\",\"user_name\":\"test-user4\",\"email\":\"test-user4@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(6,'768c3cb0ee0b9771328d','user',6,1,'value',NULL,'{\"user_code\":\"test-user5\",\"user_name\":\"test-user5\",\"email\":\"test-user5@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(7,'a56f5bc83cb1ab707b15','user',7,1,'value',NULL,'{\"user_code\":\"test-user6\",\"user_name\":\"test-user6\",\"email\":\"test-user6@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(8,'b54ff71c8650f65ba509','user',8,1,'value',NULL,'{\"user_code\":\"test-user7\",\"user_name\":\"test-user7\",\"email\":\"test-user7@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(9,'21189378aca63c102139','user',9,1,'value',NULL,'{\"user_code\":\"test-user8\",\"user_name\":\"test-user8\",\"email\":\"test-user8@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(10,'485bfde6395f80000ec5','user',10,1,'value',NULL,'{\"user_code\":\"test-user9\",\"user_name\":\"test-user9\",\"email\":\"test-user9@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL),(11,'8115240928dd85f4eabd','user',11,1,'value',NULL,'{\"user_code\":\"test-user10\",\"user_name\":\"test-user10\",\"email\":\"test-user10@example.com\"}','2022-10-11 01:29:44','2022-10-11 01:29:44',NULL,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 10:33:18
