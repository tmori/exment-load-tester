<?php

// (1)
namespace App\Plugins\PluginCustomPage;

use Encore\Admin\Widgets\Box;
use Exceedone\Exment\Model\CustomTable;
use Exceedone\Exment\Services\Plugin\PluginPageBase;
use GuzzleHttp\Client;

class Plugin extends PluginPageBase
{

    /**
     * Index
     *
     * @return void
     */
    public function index()
    {
        return $this->getIndexBox();
    }

    protected function getIndexBox(){

        return new Box("学籍番号入力", view('exment_custom_page::index'));
    }

}