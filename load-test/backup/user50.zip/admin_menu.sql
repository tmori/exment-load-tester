-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `admin_menu`
--

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'HOME','fa-home','/',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','home','home'),(2,0,2,'マスター管理','fa-database','#',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','parent_node','master',NULL),(3,0,91,'管理者設定','fa-user-circle-o','#',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','parent_node','admin',NULL),(4,2,1,'基本情報','fa-building','base_info',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','table','base_info','3'),(5,2,2,'組織','fa-sitemap','organization',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','table','organization','5'),(6,2,3,'ユーザー','fa-user','user',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','table','user','4'),(7,2,4,'お知らせ','fa-exclamation','information',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','table','information','8'),(8,3,1,'システム設定','fa-cogs','system',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','system','system'),(9,3,2,'カスタムテーブル','fa-table','table',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','custom_table','custom_table'),(10,3,3,'メニュー','fa-sitemap','auth/menu',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','menu','menu'),(11,3,4,'テンプレート','fa-clone','template',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','template','template'),(12,3,5,'バックアップ','fa-database','backup',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','backup','backup'),(13,3,6,'ログインユーザー','fa-user-plus','loginuser',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','loginuser','loginuser'),(14,3,7,'役割グループ','fa-user-secret','role_group',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','role_group','role_group'),(15,3,8,'ワークフロー','fa-share-alt','workflow',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','workflow','workflow'),(16,3,9,'プラグイン','fa-plug','plugin',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','system','plugin','plugin'),(17,3,11,'通知テンプレート','fa-bell-o','mail_template',NULL,NULL,'2022-10-11 00:01:12','2022-10-11 00:01:12','table','mail_template','6');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 10:34:58
