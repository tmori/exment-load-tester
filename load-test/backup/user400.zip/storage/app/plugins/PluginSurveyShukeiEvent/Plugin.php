<?php
namespace App\Plugins\PluginSurveyShukeiEvent;

use Exceedone\Exment\Services\Plugin\PluginEventBase;
use Exceedone\Exment\Model\CustomTable;

class Plugin extends PluginEventBase
{
    private function before_save()
    {
        \Log::debug('Event called! table_name=' . $this->custom_table->table_name);
        $score = 0;
        foreach ($this->custom_table->custom_columns as $column) {
            //\Log::debug('Column name=' . $column->column_name);
            $value =  $this->custom_value->getValue($column->column_name);
            //\Log::debug('Column value=' . $value );
            if (strpos($column->column_name, 'q_') !== false) {
                $score = $score + $value;
            }
        }
        $this->custom_value->setValue('score', $score);
    }
    private function after_save()
    {
        $items = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel()->get();
        $count = $items->count();
        $sum = 0;
        $max = 0;
        $min = 99999;
        $ave = 0.0;
        foreach ($items as $item) {
            $value = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel($item->id);
            $e_score = $value->getValue('score');
	        \Log::debug('score=' . $e_score);
            if ($e_score > $max) {
                $max = $e_score;
            }
            if ($e_score < $min) {
                $min = $e_score;
            }
            $sum += $e_score;
        }
        if ($count > 0) {
            $ave = $sum / $count;
        }
        \Log::debug('MAX=' . $max);
        \Log::debug('MIN=' . $min);
        \Log::debug('SUM=' . $sum);
        \Log::debug('CNT=' . $count);
        \Log::debug('AVE=' . $ave);

        $models = CustomTable::getEloquent('shukei_survery')->getValueModel()->get();
        foreach ($models as $model) {
            $model->setValue('max', $max);
            $model->setValue('min', $min);
            $model->setValue('sum', $sum);
            $model->setValue('average', $ave);
            $model->setValue('number_elms', $count);
            $model->save();
        }
    }
    /**
     * Plugin Trigger
     */
    public function execute()
    {
        \Log::debug('Plugin Trigger exute():enter');
        $this->before_save();
        $this->after_save();
        \Log::debug('Plugin Trigger exute():exit');
        return true;
    }
}