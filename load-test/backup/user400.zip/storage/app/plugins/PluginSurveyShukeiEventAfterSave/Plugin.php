<?php
namespace App\Plugins\PluginSurveyShukeiEventAfterSave;

use Exceedone\Exment\Services\Plugin\PluginEventBase;
use Exceedone\Exment\Model\CustomTable;

class Plugin extends PluginEventBase
{
    private function after_save()
    {
        $target_table_name = '';
        $models = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel()->get();
        foreach ($models as $model) {
            $value = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel($model->id);
            $target_table_name = $value->getValue('target');
            break;
        }
        \Log::debug('target_table_name=' . $target_table_name);

        $items = CustomTable::getEloquent($target_table_name)->getValueModel()->get();
        $count = $items->count();
        $sum = 0;
        $max = 0;
        $min = 99999;
        $ave = 0.0;
        foreach ($items as $item) {
            $value = CustomTable::getEloquent($target_table_name)->getValueModel($item->id);
            $e_score = $value->getValue('score');
            if ($e_score > $max) {
                $max = $e_score;
            }
            if ($e_score < $min) {
                $min = $e_score;
            }
            $sum += $e_score;
        }
        if ($count > 0) {
            $ave = $sum / $count;
        }
        \Log::debug('MAX=' . $max);
        \Log::debug('MIN=' . $min);
        \Log::debug('SUM=' . $sum);
        \Log::debug('CNT=' . $count);
        \Log::debug('AVE=' . $ave);

        $models = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel()->get();
        foreach ($models as $model) {
            $value = CustomTable::getEloquent($this->custom_table->table_name)->getValueModel($model->id);
            \Log::debug('getValue=' . $value->getValue('target'));
            if (strcmp($value->getValue('target'), $target_table_name) == 0) {
                $model->setValue('max', $max);
                $model->setValue('min', $min);
                $model->setValue('sum', $sum);
                $model->setValue('average', $ave);
                $model->setValue('number_elms', $count);
                $model->save();
                \Log::debug('SAVED=' . $ave);
                break;
            }
        }
    }
    /**
     * Plugin Trigger
     */
    public function execute()
    {
        $this->after_save();
        return true;
    }
}