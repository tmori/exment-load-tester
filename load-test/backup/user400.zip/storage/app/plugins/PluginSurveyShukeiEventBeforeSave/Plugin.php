<?php
namespace App\Plugins\PluginSurveyShukeiEventBeforeSave;

use Exceedone\Exment\Services\Plugin\PluginEventBase;
use Exceedone\Exment\Model\CustomTable;

class Plugin extends PluginEventBase
{
    private function before_save()
    {
        \Log::debug('Event called! table_name=' . $this->custom_table->table_name);
        $score = 0;
        foreach ($this->custom_table->custom_columns as $column) {
            \Log::debug('Column name=' . $column->column_name);
            $value =  $this->custom_value->getValue($column->column_name);
            \Log::debug('Column value=' . $value );
            if (strpos($column->column_name, 'q_') !== false) {
                $score = $score + $value;
            }
        }
        $this->custom_value->setValue('score', $score);
    }

    /**
     * Plugin Trigger
     */
    public function execute()
    {
        $this->before_save();
        return true;
    }
}