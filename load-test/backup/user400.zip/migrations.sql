-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: exment_database
-- ------------------------------------------------------
-- Server version	10.3.34-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2018_04_27_021034_create_table_define',1),(5,'2019_03_11_193513_patch_authoritable',1),(6,'2019_03_28_185921_oauth_clientid_uuid',1),(7,'2019_04_15_115120_support_for_v1_1',1),(8,'2019_04_25_185014_drop_unique_keys',1),(9,'2019_05_18_164730_support_for_v1_2',1),(10,'2019_05_23_165335_patch_user_accessable',1),(11,'2019_05_28_165146_create_custom_column_multi',1),(12,'2019_06_06_130456_plugin_custom_option',1),(13,'2019_06_12_193431_support_for_v1_3',1),(14,'2019_06_18_135639_update_custom_view_summary',1),(15,'2019_07_11_105602_support_for_v1_4',1),(16,'2019_07_12_120518_support_for_v2_0',1),(17,'2019_08_07_095018_init_column',1),(18,'2019_08_19_000000_create_failed_jobs_table',1),(19,'2019_08_19_151648_support_for_v2_1',1),(20,'2019_09_12_120518_support_for_v2_1_4',1),(21,'2019_09_19_093842_support_for_v2_1_7',1),(22,'2019_09_19_093842_support_for_v3_0_0',1),(23,'2019_12_14_000001_create_personal_access_tokens_table',1),(24,'2020_01_16_000000_remove_deleted_column',1),(25,'2020_02_20_155520_add_options_to_filters',1),(26,'2020_02_26_000000_add_notify_name',1),(27,'2020_03_22_000000_patch_dashboard_box',1),(28,'2020_04_02_000000_api_auth_api_key',1),(29,'2020_04_07_125924_add_options_to_workflows',1),(30,'2020_05_01_000000_patch_log_operation_update',1),(31,'2020_05_05_000000_support_for_v3_2_0',1),(32,'2020_06_14_000000_support_for_v3_3_0',1),(33,'2020_06_16_000000_patch_form_column_relation',1),(34,'2020_06_25_000000_append_view_column_suuid',1),(35,'2020_07_03_160259_support_for_v3_4_0',1),(36,'2020_07_15_160217_external_custom_operation',1),(37,'2020_07_16_000000_patch_view_dashboard',1),(38,'2020_08_14_000000_patch_view_filters',1),(39,'2020_09_25_000000_update_notify_logic',1),(40,'2020_09_29_000000_workflow_value_view',1),(41,'2020_10_23_000000_patch_view_only',1),(42,'2020_12_15_000000_patch_calc_data',1),(43,'2021_01_05_000000_plugin_view',1),(44,'2021_02_13_000000_patch_condition_data',1),(45,'2021_03_05_000000_public_form_and_options',1),(46,'2021_04_21_165617_add_options_to_custom_view_sort',1),(47,'2021_07_14_160709_add_column_type_to_operation',1),(48,'2021_07_15_092440_patch_import_export_permission',1),(49,'2021_12_02_000000_patch_mail_attachments',1),(50,'2022_01_01_000000_workflow_patch',1),(51,'2022_01_11_000000_patch_mail_custom_attachments',1),(52,'2022_01_13_133748_patch_laravel8',1),(53,'2022_01_18_000000_patch_custom_column_editable_userinfo',1),(54,'2022_06_17_133748_patch_php8',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-11 10:38:56
